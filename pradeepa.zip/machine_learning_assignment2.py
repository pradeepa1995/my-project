import pandas as pd
from sklearn.tree import DecisionTreeClassifier, plot_tree
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score,classification_report,confusion_matrix

#dataset
df = pd.read_csv("diabetes_dataset.csv")
print(df.head(20))


x = df.drop("Outcome",axis=1)
y = df["Outcome"]


#split the datasets
X_train, X_test, y_train, y_test = train_test_split( x,y, test_size=0.4, random_state=42)

#model define
model = DecisionTreeClassifier(criterion='gini', max_depth=3, random_state=42)
model.fit(X_train, y_train)

# Predict on test data
y_pred = model.predict(X_test)

# Calculate metrics
print(accuracy_score(y_test, y_pred))
print(classification_report(y_test, y_pred))
print(confusion_matrix(y_test, y_pred))
#visualation
plt.figure(figsize=(10, 8))
plot_tree(model, feature_names=x.columns, class_names=['No', 'Yes'], filled=True)
plt.show()





